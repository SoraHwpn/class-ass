<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<div class="container">
    <a class="btn btn-primary mt-5" href="<?php echo e(route('posts.index')); ?>">Go to created</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>#</th>
                <th>name</th>
                <th>description</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($data->id); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->description); ?></td>
                <td><?php echo e($data->is_active ? 'Active' : 'Suspended'); ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\laratest\resources\views/posts/show.blade.php ENDPATH**/ ?>