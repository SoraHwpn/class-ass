<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<div class="container">
    <div class="row justify-content-center">
        <form action="<?php echo e(route('posts.update', $data->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo e(method_field('PATCH')); ?>

            <div class="col-md-6 mt-5">
                <h1>Blog Edit</h1>
                <div>
                    <label for="">Name</label>
                    <input name="name" id="name" class="form-control mt-2" type="text"
                        value="<?php echo e($data->name); ?>">
                </div>
                <div>
                    <label for="">Description</label>
                    <input name="description" id="description" class="form-control mt-2" type="text"
                        value="<?php echo e($data->description); ?>">
                </div>
                <div>
                    <input type="radio" value="active" name="radio" checked>
                    <label>Active</label>
                    <input type="radio" value="suspend" name="radio">
                    <label>suspend</label>
                </div>
                <button type="submit" class="btn btn-primary mt-2">Edit</button>
            </div>
        </form>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('js/bootstrap.js')); ?>">
<?php /**PATH C:\xampp\htdocs\laratest\resources\views/posts/edit.blade.php ENDPATH**/ ?>