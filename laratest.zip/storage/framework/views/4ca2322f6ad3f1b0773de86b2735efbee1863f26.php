<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<div class="container">
    <a class="btn btn-primary mt-5" href="<?php echo e(route('blogs.index')); ?>">Go to created</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>#</th>
                <th>name</th>
                <th>image</th>
                <th>description</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($data->id); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->imgae); ?></td>
                <td><?php echo e($data->description); ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\laratest\resources\views/blogs/show.blade.php ENDPATH**/ ?>