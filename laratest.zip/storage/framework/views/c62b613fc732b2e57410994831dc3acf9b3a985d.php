<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<div class="container">
    <div class="row justify-content-center">
      <form action="<?php echo e(route('blogs.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="col-md-6 mt-5">
            <h1>Created List</h1>
            <div>
                <label for="">Name</label>
                <input name="name" class="form-control mt-2" type="text">
            </div>
            <div>
                <label for="">Description</label>
                <input name="description" class="form-control mt-2" type="text">
            </div>
            <button class="btn btn-primary mt-2">Create</button>
        </div>
      </form>
    </div>
</div>
<link rel="stylesheet" href="<?php echo e(asset('js/bootstrap.js')); ?>">
<?php /**PATH C:\xampp\htdocs\laratest\resources\views/blogs/create.blade.php ENDPATH**/ ?>