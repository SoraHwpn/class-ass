<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
<div class="container">
    <a class="btn btn-primary mt-5" href="<?php echo e(route('blogs.create')); ?>">Go to created</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($val->id); ?></td>
                    <td><?php echo e($val->name); ?></td>
                    <td><?php echo e($val->imgae); ?></td>
                    <td><?php echo e($val->description); ?></td>
                    <td><a class="btn btn-primary" href="<?php echo e(route('blogs.edit', $val->id)); ?>">Edit</a>
                        <a class="btn btn-success" href="<?php echo e(route('blogs.show', $val->id)); ?>">View</a>
                        <form action="<?php echo e(route('blogs.destroy', $val->id)); ?>" method="post" class="mt-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\laratest\resources\views/blogs/index.blade.php ENDPATH**/ ?>