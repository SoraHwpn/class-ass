<link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
<div class="container">
    <div class="row justify-content-center">
        <form action="{{ route('blogs.update', $data->id) }}" method="post">
            @csrf
            {{ method_field('PATCH') }}
            <div class="col-md-6 mt-5">
                <h1>Blog Edit</h1>
                <div>
                    <label for="">Name</label>
                    <input name="name" id="name" class="form-control mt-2" type="text"
                        value="{{ $data->name }}">
                </div>
                <div>
                    <label for="">Description</label>
                    <input name="description" id="description" class="form-control mt-2" type="text"
                        value="{{ $data->description }}">
                </div>
                <button type="submit" class="btn btn-primary mt-2">Edit</button>
            </div>
        </form>
    </div>
</div>
<link rel="stylesheet" href="{{ asset('js/bootstrap.js') }}">
