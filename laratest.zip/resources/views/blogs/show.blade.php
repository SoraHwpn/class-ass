<link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
<div class="container">
    <a class="btn btn-primary mt-5" href="{{ route('blogs.index') }}">Go to created</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>#</th>
                <th>name</th>
                <th>image</th>
                <th>description</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ $data->id }}</td>
                <td>{{ $data->name }}</td>
                <td>{{ $data->imgae }}</td>
                <td>{{ $data->description }}</td>
            </tr>
        </tbody>
    </table>
</div>
