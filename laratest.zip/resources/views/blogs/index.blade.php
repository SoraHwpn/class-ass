<link rel="stylesheet" href="{{ asset('css/bootstrap.css') }}">
<div class="container">
    <a class="btn btn-primary mt-5" href="{{ route('blogs.create') }}">Go to created</a>
    <table class="table mt-3">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($data as $val)
                <tr>
                    <td>{{ $val->id }}</td>
                    <td>{{ $val->name }}</td>
                    <td>{{ $val->imgae }}</td>
                    <td>{{ $val->description }}</td>
                    <td><a class="btn btn-primary" href="{{ route('blogs.edit', $val->id) }}">Edit</a>
                        <a class="btn btn-success" href="{{ route('blogs.show', $val->id) }}">View</a>
                        <form action="{{ route('blogs.destroy', $val->id) }}" method="post" class="mt-2">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
